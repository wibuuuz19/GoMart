import '../src/styles/style.css';
import '../src/styles/responsive.css';